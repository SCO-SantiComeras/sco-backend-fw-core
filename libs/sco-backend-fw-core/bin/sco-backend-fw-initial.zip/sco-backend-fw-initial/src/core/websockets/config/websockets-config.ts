export class WebsocketsConfig {
  enabled: boolean;
  port: number;
  origin: string;
}
