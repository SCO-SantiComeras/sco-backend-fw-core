export const WEBSOCKETS_CONSTANTS = {
    /* USERS: 'WS_USERS', */
}