export const WEBSOCKETS_CONSTANTS = {
    /* WS_USERS: 'WS_USERS', */
}