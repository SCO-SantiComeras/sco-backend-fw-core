export const MONGODB_CONSTANTS = {
    /* USERS: {
        MODEL: 'User',
        TABLE: 'users',
    }, */
}