() => {
    return 'Hello World!';
}